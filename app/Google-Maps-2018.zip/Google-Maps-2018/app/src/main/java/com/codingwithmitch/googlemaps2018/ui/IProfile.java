package com.codingwithmitch.googlemaps2018.ui;

public interface IProfile {

    void onImageSelected(int resource);
}
